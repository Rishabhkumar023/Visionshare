
import { GoogleGenAI, Type } from "@google/genai";
import type { AISummary } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const summarySchema = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: "A concise, engaging title for the session summary. Should be 3-7 words."
    },
    summaryPoints: {
      type: Type.ARRAY,
      description: "A bulleted list of 3-5 key discussion points or takeaways from the session.",
      items: { type: Type.STRING }
    },
    actionItems: {
      type: Type.ARRAY,
      description: "A bulleted list of 2-4 concrete, actionable next steps.",
      items: { type: Type.STRING }
    }
  },
  required: ["title", "summaryPoints", "actionItems"]
};


export const generateSessionSummary = async (topic: string): Promise<AISummary> => {
  try {
    const prompt = `You are a productivity assistant. Your task is to generate a concise summary and a list of action items based on a user's description of a screen sharing session. The user's session was about: "${topic}". Please generate a title, key summary points, and actionable next steps.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: summarySchema,
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const parsedJson = JSON.parse(jsonText);

    // Basic validation to ensure the parsed object matches the expected structure
    if (
      !parsedJson.title || 
      !Array.isArray(parsedJson.summaryPoints) || 
      !Array.isArray(parsedJson.actionItems)
    ) {
      throw new Error("AI response is not in the expected format.");
    }
    
    return parsedJson as AISummary;

  } catch (error) {
    console.error("Error generating session summary:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate AI summary: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating the AI summary.");
  }
};