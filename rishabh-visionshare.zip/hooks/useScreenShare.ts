
import { useState, useCallback, useRef, useEffect } from 'react';

export const useScreenShare = () => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isSharing, setIsSharing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopSharing = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setStream(null);
    setIsSharing(false);
  }, []);

  const startSharing = useCallback(async () => {
    // Stop any existing stream before starting a new one
    if (streamRef.current) {
      stopSharing();
    }

    try {
      setError(null);
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          cursor: "always"
        } as any, // FIX: Cast to 'any' to allow the 'cursor' property which is valid but not in standard TS DOM types.
        audio: true
      });

      // Listen for the user stopping the share via browser UI
      const videoTrack = displayStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          stopSharing();
        };
      }

      streamRef.current = displayStream;
      setStream(displayStream);
      setIsSharing(true);

    } catch (err) {
      console.error("Error starting screen share:", err);
      if (err instanceof Error) {
        if (err.name === "NotAllowedError") {
          setError("Screen sharing permission was denied. Please allow permission and try again.");
        } else {
          setError(`An error occurred: ${err.message}`);
        }
      } else {
        setError("An unknown error occurred while trying to start screen sharing.");
      }
      setIsSharing(false);
    }
  }, [stopSharing]);
  
  // Cleanup effect
  useEffect(() => {
    return () => {
        stopSharing();
    };
  }, [stopSharing]);


  return { stream, isSharing, error, startSharing, stopSharing };
};