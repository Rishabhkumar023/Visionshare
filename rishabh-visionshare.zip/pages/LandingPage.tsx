
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HeroSection from '../components/HeroSection';
import FeatureCard from '../components/FeatureCard';
import { ScreenShareIcon } from '../components/icons/ScreenShareIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { LockIcon } from '../components/icons/LockIcon';


const LandingPage: React.FC = () => {
  const features = [
    {
      icon: <ScreenShareIcon />,
      title: "Seamless HD Sharing",
      description: "Share your screen in high definition with a single click. Perfect for demos, presentations, and collaborative work."
    },
    {
      icon: <SparklesIcon />,
      title: "AI-Powered Summaries",
      description: "Never lose track of important details. Automatically generate summaries and action items after your session ends."
    },
    {
      icon: <LockIcon />,
      title: "Secure & Private",
      description: "Your privacy is our priority. All screen sharing streams are peer-to-peer and protected."
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-900 animate-fade-in">
      <Header />
      <main className="flex-grow">
        <HeroSection />
        
        <section id="features" className="py-20 sm:py-32">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-white">Why VisionShare?</h2>
              <p className="mt-4 text-lg text-gray-400">Everything you need for productive collaboration.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <FeatureCard key={index} icon={feature.icon} title={feature.title} description={feature.description} />
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default LandingPage;