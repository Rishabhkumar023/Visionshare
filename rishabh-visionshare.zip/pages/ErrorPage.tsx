
import React from 'react';

interface ErrorPageProps {
  onReset?: () => void;
}

const ErrorPage: React.FC<ErrorPageProps> = ({ onReset }) => {
  const handleReset = () => {
    if (onReset) {
      onReset();
    } else {
      // Default fallback if no reset handler is provided
      window.location.href = '/';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white text-center px-4 animate-fade-in">
        <div className="w-full max-w-md p-8 bg-gray-800/50 border border-gray-700 rounded-xl">
            <h1 className="text-4xl font-bold text-red-500 mb-4">Oops!</h1>
            <h2 className="text-2xl font-semibold mb-4 text-white">Something Went Wrong</h2>
            <p className="text-gray-400 mb-8">
                We've encountered an unexpected error. Our team has been notified.
            </p>
            <button
                onClick={handleReset}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105"
            >
                Go to Homepage
            </button>
        </div>
    </div>
  );
};

export default ErrorPage;
