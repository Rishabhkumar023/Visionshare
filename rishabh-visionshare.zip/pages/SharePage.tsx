
import React, { useState, useCallback } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ScreenShareController from '../components/ScreenShareController';
import SummaryGenerator from '../components/SummaryGenerator';

const SharePage: React.FC = () => {
  const [sessionEnded, setSessionEnded] = useState(false);

  const handleSessionEnd = useCallback(() => {
    setSessionEnded(true);
  }, []);

  const handleStartNewSession = useCallback(() => {
    setSessionEnded(false);
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-900">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 flex flex-col items-center justify-center">
        {!sessionEnded ? (
          <ScreenShareController onSessionEnd={handleSessionEnd} />
        ) : (
          <SummaryGenerator onStartNewSession={handleStartNewSession} />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default SharePage;