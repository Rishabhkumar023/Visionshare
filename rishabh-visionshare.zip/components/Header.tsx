
import React from 'react';
import { Link } from 'react-router-dom';
import { ScreenShareIcon } from './icons/ScreenShareIcon';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2 text-xl font-bold text-white">
            <ScreenShareIcon />
            <span>VisionShare</span>
        </Link>
        <nav>
          <Link 
            to="/login" 
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
          >
            Start Sharing
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;