
import React, { useRef, useEffect, useCallback } from 'react';
import { useScreenShare } from '../hooks/useScreenShare';

interface ScreenShareControllerProps {
  onSessionEnd: () => void;
}

const ScreenShareController: React.FC<ScreenShareControllerProps> = ({ onSessionEnd }) => {
  const { stream, isSharing, error, startSharing, stopSharing } = useScreenShare();
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const handleStopSharing = useCallback(() => {
    stopSharing();
    // onSessionEnd is now handled by the useEffect below to avoid double calls
  }, [stopSharing]);

  // Effect to call onSessionEnd if isSharing becomes false.
  // This handles both button clicks and browser UI stops consistently.
  const wasSharing = useRef(isSharing);
  useEffect(() => {
    if (wasSharing.current && !isSharing) {
        onSessionEnd();
    }
    wasSharing.current = isSharing;
  }, [isSharing, onSessionEnd]);

  return (
    <div className="w-full max-w-4xl p-8 bg-gray-800/50 border border-gray-700 rounded-xl flex flex-col items-center animate-fade-in">
      <h2 className="text-2xl font-bold text-white mb-4">Screen Sharing</h2>
      <div className="w-full aspect-video bg-black rounded-lg mb-6 overflow-hidden border border-gray-700">
        {isSharing ? (
           <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-contain" />
        ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-500">
                <p>Your screen share will appear here.</p>
            </div>
        )}
      </div>

      {error && <p className="text-red-400 mb-4 text-center">{error}</p>}
      
      <div className="flex space-x-4">
        {!isSharing ? (
          <button
            onClick={startSharing}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-6 rounded-lg transition-colors"
          >
            Start Sharing
          </button>
        ) : (
          <button
            onClick={handleStopSharing}
            className="bg-red-600 hover:bg-red-500 text-white font-bold py-3 px-6 rounded-lg transition-colors"
          >
            Stop Sharing
          </button>
        )}
      </div>
       <p className="text-gray-400 mt-4 text-sm">
        {isSharing ? "You are currently sharing your screen." : "Click 'Start Sharing' to begin."}
      </p>
    </div>
  );
};

export default ScreenShareController;