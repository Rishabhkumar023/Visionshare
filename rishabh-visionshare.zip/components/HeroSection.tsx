
import React from 'react';
import { Link } from 'react-router-dom';

const HeroSection: React.FC = () => {
  return (
    <section className="relative text-center py-24 sm:py-40 px-6 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 animate-gradient-bg bg-[size:400%_400%]"></div>
      <div className="relative z-10">
        <h1 className="text-4xl sm:text-6xl font-black text-white leading-tight tracking-tight">
          Share Your Vision, <br/>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-pink-500">
            Smarter & Faster
          </span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-lg sm:text-xl text-gray-300">
          The intelligent screen sharing platform that turns your presentations and demos into actionable insights with AI-powered summaries.
        </p>
        <div className="mt-10">
          <Link
            to="/login"
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105"
          >
            Get Started for Free
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;