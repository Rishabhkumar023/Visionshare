
import React, { useState, useCallback } from 'react';
import { generateSessionSummary } from '../services/geminiService';
import type { AISummary } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface SummaryGeneratorProps {
  onStartNewSession: () => void;
}

const SummaryGenerator: React.FC<SummaryGeneratorProps> = ({ onStartNewSession }) => {
  const [topic, setTopic] = useState('');
  const [summary, setSummary] = useState<AISummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateSummary = useCallback(async () => {
    if (!topic.trim()) {
      setError("Please describe your session topic.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setSummary(null);
    try {
      const result = await generateSessionSummary(topic);
      setSummary(result);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  }, [topic]);

  if (summary) {
    return (
      <div className="w-full max-w-2xl p-8 bg-gray-800/50 border border-gray-700 rounded-xl animate-fade-in">
        <h2 className="text-2xl font-bold text-center mb-2 text-indigo-400">{summary.title}</h2>
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-white mb-2">Key Takeaways</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-300">
            {summary.summaryPoints.map((point, i) => <li key={i}>{point}</li>)}
          </ul>
        </div>
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-white mb-2">Action Items</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-300">
            {summary.actionItems.map((item, i) => <li key={i}>{item}</li>)}
          </ul>
        </div>
        <div className="mt-8 text-center">
          <button
            onClick={onStartNewSession}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Start a New Session
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-xl p-8 bg-gray-800/50 border border-gray-700 rounded-xl flex flex-col items-center animate-fade-in">
      <SparklesIcon className="text-indigo-400 w-12 h-12 mb-4" />
      <h2 className="text-2xl font-bold mb-2">Generate AI Summary</h2>
      <p className="text-gray-400 mb-6 text-center">Describe your session to generate key takeaways and action items.</p>
      
      <div className="w-full">
        <textarea
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="e.g., 'Conducted a design review for the new user dashboard.'"
          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-shadow text-white"
          rows={3}
          disabled={isLoading}
        />
        {error && <p className="text-red-400 mt-2 text-sm">{error}</p>}
      </div>

      <div className="flex items-center space-x-4 mt-6">
        <button
          onClick={handleGenerateSummary}
          disabled={isLoading}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center"
        >
          {isLoading ? (
            <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
            </>
          ) : "Generate Summary"}
        </button>
         <button
          onClick={onStartNewSession}
          disabled={isLoading}
          className="bg-gray-600 hover:bg-gray-500 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
        >
          Skip
        </button>
      </div>
    </div>
  );
};

export default SummaryGenerator;