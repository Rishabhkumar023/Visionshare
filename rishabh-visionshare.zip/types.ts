
export interface AISummary {
  title: string;
  summaryPoints: string[];
  actionItems: string[];
}